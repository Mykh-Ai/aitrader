from __future__ import annotations

import pandas as pd

from analyzer.sweeps import SWEEP_FEATURE_COLUMNS, detect_sweeps
from analyzer.swings import annotate_swings


def _hourly_df(highs: list[float], lows: list[float], start: str = "2025-01-01") -> pd.DataFrame:
    ts = pd.date_range(start=start, periods=len(highs), freq="1h", tz="UTC")
    return pd.DataFrame({"Timestamp": ts, "High": highs, "Low": lows})


def test_upward_sweep_over_confirmed_h1_swing_high():
    # H1 swing high at 01:00 (14) is confirmed at 03:00; only then sweeps can trigger.
    df = _hourly_df(highs=[10, 14, 11, 13, 15], lows=[5, 6, 6, 6, 7])

    out = detect_sweeps(annotate_swings(df))

    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z"), "Sweep_H1_Up"].iloc[0]
    row = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z")].iloc[0]
    assert row["Sweep_H1_Up"]
    assert not row["Sweep_H1_Down"]
    assert row["Sweep_H1_Direction"] == "up"
    assert row["Sweep_H1_ReferenceLevel"] == 14
    assert row["Sweep_H1_ReferenceTs"] == pd.Timestamp("2025-01-01T03:00:00Z")


def test_downward_sweep_below_confirmed_h1_swing_low():
    # H1 swing low at 01:00 (4) is confirmed at 03:00; downward sweep at 04:00.
    df = _hourly_df(highs=[9, 10, 11, 10, 9], lows=[7, 4, 6, 5, 3])

    out = detect_sweeps(annotate_swings(df))

    row = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z")].iloc[0]
    assert row["Sweep_H1_Down"]
    assert not row["Sweep_H1_Up"]
    assert row["Sweep_H1_Direction"] == "down"
    assert row["Sweep_H1_ReferenceLevel"] == 4
    assert row["Sweep_H1_ReferenceTs"] == pd.Timestamp("2025-01-01T03:00:00Z")


def test_downward_sweep_emits_only_first_cross_for_unchanged_reference():
    # Confirmed H1 swing low at 01:00 (4) is visible from 03:00 onward.
    # Multiple later bars remain below 4, but only the first down-side cross should emit.
    df = _hourly_df(highs=[10, 11, 10, 10, 10, 10], lows=[8, 4, 6, 3, 2, 1])

    out = detect_sweeps(annotate_swings(df))

    first = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z")].iloc[0]
    assert first["Sweep_H1_Down"]
    assert first["Sweep_H1_ReferenceLevel"] == 4
    assert first["Sweep_H1_ReferenceTs"] == pd.Timestamp("2025-01-01T03:00:00Z")

    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z"), "Sweep_H1_Down"].iloc[0]
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T05:00:00Z"), "Sweep_H1_Down"].iloc[0]

def test_no_sweep_before_confirmation_exists():
    # Bar at 02:00 trades above eventual swing high (14), but confirmation appears only at 03:00.
    df = _hourly_df(highs=[10, 14, 15, 10], lows=[5, 6, 7, 6])

    out = detect_sweeps(annotate_swings(df))

    row = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T02:00:00Z")].iloc[0]
    assert pd.isna(row["SwingHigh_H1_Price"])
    assert not row["Sweep_H1_Up"]


def test_sweep_emits_only_first_cross_for_unchanged_reference():
    # Confirmed H1 swing high at 01:00 (14) is visible from 03:00 onward.
    # Multiple later bars remain above 14, but only the first cross should emit.
    df = _hourly_df(highs=[10, 14, 11, 15, 16, 17], lows=[5, 6, 6, 6, 6, 6])

    out = detect_sweeps(annotate_swings(df))

    assert out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z"), "Sweep_H1_Up"].iloc[0]
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z"), "Sweep_H1_Up"].iloc[0]
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T05:00:00Z"), "Sweep_H1_Up"].iloc[0]


def test_sweep_dedup_resets_when_confirmed_reference_changes():
    # First confirmed high reference (14) is swept at 03:00.
    # Later a new confirmed high reference (16) materializes at 06:00 and can sweep again at 07:00.
    df = _hourly_df(highs=[10, 14, 11, 15, 16, 13, 12, 17], lows=[5, 6, 6, 6, 6, 6, 6, 6])

    out = detect_sweeps(annotate_swings(df))

    first = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z")].iloc[0]
    assert first["Sweep_H1_Up"]
    assert first["Sweep_H1_ReferenceLevel"] == 14

    # Re-breach of unchanged reference is suppressed.
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z"), "Sweep_H1_Up"].iloc[0]

    second = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T07:00:00Z")].iloc[0]
    assert second["Sweep_H1_Up"]
    assert second["Sweep_H1_ReferenceLevel"] == 16
    assert second["Sweep_H1_ReferenceTs"] == pd.Timestamp("2025-01-01T06:00:00Z")


def test_first_cross_dedup_is_group_local_across_reference_switch():
    # Cross on old reference at 03:00 and first cross on new reference at 07:00
    # must both emit; group-local dedup must not suppress new lineage first cross.
    df = _hourly_df(highs=[10, 14, 11, 15, 16, 13, 12, 17], lows=[5, 6, 6, 6, 6, 6, 6, 6])

    out = detect_sweeps(annotate_swings(df))

    old_ref_cross = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z")].iloc[0]
    new_ref_cross = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T07:00:00Z")].iloc[0]

    assert old_ref_cross["Sweep_H1_Up"]
    assert old_ref_cross["Sweep_H1_ReferenceLevel"] == 14
    assert new_ref_cross["Sweep_H1_Up"]
    assert new_ref_cross["Sweep_H1_ReferenceLevel"] == 16


def test_equal_touch_is_not_sweep_with_strict_rule():
    # Strict inequality: equal touch to level should not count as sweep.
    df = _hourly_df(highs=[10, 14, 11, 14], lows=[5, 6, 6, 6])

    out = detect_sweeps(annotate_swings(df))

    row = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z")].iloc[0]
    assert row["SwingHigh_H1_Price"] == 14
    assert not row["Sweep_H1_Up"]


def test_synthetic_rows_fixture_stable_and_explicit_columns():
    ts = pd.date_range("2025-01-01T00:00:00Z", periods=5, freq="1h", tz="UTC")
    df = pd.DataFrame(
        {
            "Timestamp": ts,
            "High": [10, 14, 11, 13, 15],
            "Low": [5, 6, 6, 6, 7],
            "IsSynthetic": [False, False, True, False, False],
        }
    )

    out = detect_sweeps(annotate_swings(df))

    assert len(out) == len(df)
    for col in SWEEP_FEATURE_COLUMNS:
        assert col in out.columns


def test_h1_h4_plumbing_sweeps_work_independently():
    ts = pd.date_range("2025-01-01T00:00:00Z", periods=16, freq="1h", tz="UTC")
    # 4H highs per bar: [10, 20, 15, 14] -> H4 swing-high=20 confirmed at 12:00.
    highs = [8, 10, 9, 7, 16, 20, 18, 17, 14, 15, 13, 12, 13, 21, 12, 11]
    lows = [5, 6, 5, 4, 8, 9, 8, 7, 6, 7, 6, 5, 6, 7, 6, 5]
    df = pd.DataFrame({"Timestamp": ts, "High": highs, "Low": lows})

    out = detect_sweeps(annotate_swings(df))

    pre_h4_confirm = out.loc[out["Timestamp"] < pd.Timestamp("2025-01-01T12:00:00Z")]
    assert not pre_h4_confirm["Sweep_H4_Up"].any()

    h4_sweep_row = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T13:00:00Z")].iloc[0]
    assert h4_sweep_row["Sweep_H4_Up"]
    assert h4_sweep_row["Sweep_H4_Direction"] == "up"
    assert h4_sweep_row["Sweep_H4_ReferenceLevel"] == 20
    assert h4_sweep_row["Sweep_H4_ReferenceTs"] == pd.Timestamp("2025-01-01T12:00:00Z")

    assert out["Sweep_H1_Up"].dtype == bool
    assert out["Sweep_H4_Down"].dtype == bool


def test_sweep_flags_are_mutually_exclusive_per_timeframe():
    ts = pd.date_range("2025-01-01T00:00:00Z", periods=16, freq="1h", tz="UTC")
    highs = [8, 10, 9, 7, 16, 20, 18, 17, 14, 15, 13, 12, 13, 21, 12, 11]
    lows = [5, 6, 5, 4, 8, 9, 8, 7, 6, 7, 6, 5, 6, 7, 6, 5]
    df = pd.DataFrame({"Timestamp": ts, "High": highs, "Low": lows})

    out = detect_sweeps(annotate_swings(df))

    for tf_label in ("H1", "H4"):
        both = out[f"Sweep_{tf_label}_Up"] & out[f"Sweep_{tf_label}_Down"]
        assert not both.any(), f"{tf_label} has rows with both up and down sweeps"


def test_sweep_fields_remain_consistent_with_flags_and_references():
    ts = pd.date_range("2025-01-01T00:00:00Z", periods=16, freq="1h", tz="UTC")
    highs = [8, 10, 9, 7, 16, 20, 18, 17, 14, 15, 13, 12, 13, 21, 12, 11]
    lows = [5, 6, 5, 4, 8, 9, 8, 7, 6, 7, 6, 5, 6, 7, 6, 5]
    df = pd.DataFrame({"Timestamp": ts, "High": highs, "Low": lows})

    out = detect_sweeps(annotate_swings(df))

    for tf_label in ("H1", "H4"):
        up_col = f"Sweep_{tf_label}_Up"
        down_col = f"Sweep_{tf_label}_Down"
        direction_col = f"Sweep_{tf_label}_Direction"
        ref_level_col = f"Sweep_{tf_label}_ReferenceLevel"
        ref_ts_col = f"Sweep_{tf_label}_ReferenceTs"
        high_level_col = f"SwingHigh_{tf_label}_Price"
        low_level_col = f"SwingLow_{tf_label}_Price"
        high_ts_col = f"SwingHigh_{tf_label}_ConfirmedAt"
        low_ts_col = f"SwingLow_{tf_label}_ConfirmedAt"

        for _, row in out.iterrows():
            if row[up_col]:
                assert not row[down_col]
                assert row[direction_col] == "up"
                assert row[ref_level_col] == row[high_level_col]
                assert row[ref_ts_col] == row[high_ts_col]
            elif row[down_col]:
                assert not row[up_col]
                assert row[direction_col] == "down"
                assert row[ref_level_col] == row[low_level_col]
                assert row[ref_ts_col] == row[low_ts_col]
            else:
                assert pd.isna(row[direction_col])
                assert pd.isna(row[ref_level_col])
                assert pd.isna(row[ref_ts_col])


def test_synthetic_row_cannot_trigger_sweep_even_if_price_crosses_level():
    ts = pd.date_range("2025-01-01T00:00:00Z", periods=5, freq="1h", tz="UTC")
    df = pd.DataFrame(
        {
            "Timestamp": ts,
            "High": [10.0, 14.0, 11.0, 16.0, 15.0],
            "Low": [5.0, 6.0, 6.0, 6.0, 7.0],
            "IsSynthetic": [0, 0, 0, 1, 0],
        }
    )

    out = detect_sweeps(annotate_swings(df))

    synth_row = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z")].iloc[0]
    assert not synth_row["Sweep_H1_Up"]
    assert not synth_row["Sweep_H1_Down"]
    assert pd.isna(synth_row["Sweep_H1_Direction"])
    assert pd.isna(synth_row["Sweep_H1_ReferenceLevel"])
    assert pd.isna(synth_row["Sweep_H1_ReferenceTs"])


def test_no_sweep_before_real_row_anchor_when_confirmation_lands_on_synthetic_segment():
    ts = pd.date_range("2025-01-01T00:00:00Z", periods=6, freq="1h", tz="UTC")
    df = pd.DataFrame(
        {
            "Timestamp": ts,
            "High": [10.0, 14.0, 11.0, 20.0, 21.0, 22.0],
            "Low": [5.0, 6.0, 6.0, 6.0, 7.0, 7.0],
            "IsSynthetic": [0, 0, 0, 1, 1, 0],
        }
    )

    out = detect_sweeps(annotate_swings(df))

    # Swing at 01:00 is confirmed at 03:00, but 03:00 and 04:00 are synthetic.
    assert pd.isna(out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z"), "SwingHigh_H1_Price"]).iloc[0]
    assert pd.isna(out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z"), "SwingHigh_H1_Price"]).iloc[0]

    # First visibility is on the first real row >= confirm_ts, so first eligible sweep is 05:00.
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z"), "Sweep_H1_Up"].iloc[0]
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z"), "Sweep_H1_Up"].iloc[0]
    assert out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T05:00:00Z"), "Sweep_H1_Up"].iloc[0]


def test_penetration_metadata_is_observation_only_and_versioned():
    df = _hourly_df(highs=[10.0, 14.0, 11.0, 15.0], lows=[5.0, 6.0, 6.0, 6.0])

    out = detect_sweeps(annotate_swings(df))

    row = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z")].iloc[0]
    assert row["Sweep_H1_Up"]
    assert row["Sweep_H1_ReferenceLevel"] == 14.0
    assert row["Sweep_H1_PenetrationAbs"] == 1.0
    assert row["Sweep_H1_PenetrationRel"] == 1.0 / 14.0
    assert row["Sweep_H1_PenetrationBand"] == "deep"
    assert row["Sweep_H1_PenetrationModelVersion"] == "v1_observation_only"

    no_sweep = out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T02:00:00Z")].iloc[0]
    assert pd.isna(no_sweep["Sweep_H1_PenetrationAbs"])
    assert pd.isna(no_sweep["Sweep_H1_PenetrationRel"])
    assert pd.isna(no_sweep["Sweep_H1_PenetrationBand"])
    assert pd.isna(no_sweep["Sweep_H1_PenetrationModelVersion"])


def test_penetration_metadata_does_not_modify_first_cross_dedup_semantics():
    df = _hourly_df(highs=[10, 14, 11, 15, 16, 17], lows=[5, 6, 6, 6, 6, 6])

    out = detect_sweeps(annotate_swings(df))

    assert out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z"), "Sweep_H1_Up"].iloc[0]
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z"), "Sweep_H1_Up"].iloc[0]
    assert not out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T05:00:00Z"), "Sweep_H1_Up"].iloc[0]

    assert out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T03:00:00Z"), "Sweep_H1_PenetrationAbs"].iloc[0] == 1
    assert pd.isna(out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T04:00:00Z"), "Sweep_H1_PenetrationAbs"].iloc[0])
    assert pd.isna(out.loc[out["Timestamp"] == pd.Timestamp("2025-01-01T05:00:00Z"), "Sweep_H1_PenetrationAbs"].iloc[0])
