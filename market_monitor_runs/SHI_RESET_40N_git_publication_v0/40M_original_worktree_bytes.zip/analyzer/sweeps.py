"""Sweep detection against already confirmed structural swing levels (Phase 1C)."""

from __future__ import annotations

import pandas as pd

PENETRATION_MODEL_VERSION = "v1_observation_only"

SWEEP_FEATURE_COLUMNS = [
    "Sweep_H1_Up",
    "Sweep_H1_Down",
    "Sweep_H1_Direction",
    "Sweep_H1_ReferenceLevel",
    "Sweep_H1_ReferenceTs",
    "Sweep_H1_PenetrationAbs",
    "Sweep_H1_PenetrationRel",
    "Sweep_H1_PenetrationBand",
    "Sweep_H1_PenetrationModelVersion",
    "Sweep_H4_Up",
    "Sweep_H4_Down",
    "Sweep_H4_Direction",
    "Sweep_H4_ReferenceLevel",
    "Sweep_H4_ReferenceTs",
    "Sweep_H4_PenetrationAbs",
    "Sweep_H4_PenetrationRel",
    "Sweep_H4_PenetrationBand",
    "Sweep_H4_PenetrationModelVersion",
]


def _first_cross_only(
    cross_mask: pd.Series,
    reference_level: pd.Series,
    reference_ts: pd.Series,
) -> pd.Series:
    """Keep only the first qualifying cross per unchanged reference lineage."""
    if not cross_mask.any():
        return cross_mask

    cross_hits = cross_mask.astype("int64")
    hits_for_reference = cross_hits.groupby([reference_level, reference_ts], dropna=False).cumsum()
    return cross_mask & (hits_for_reference == 1)


def _annotate_tf_sweeps(out: pd.DataFrame, tf_label: str) -> pd.DataFrame:
    high_price_col = f"SwingHigh_{tf_label}_Price"
    high_ts_col = f"SwingHigh_{tf_label}_ConfirmedAt"
    low_price_col = f"SwingLow_{tf_label}_Price"
    low_ts_col = f"SwingLow_{tf_label}_ConfirmedAt"

    up_col = f"Sweep_{tf_label}_Up"
    down_col = f"Sweep_{tf_label}_Down"
    direction_col = f"Sweep_{tf_label}_Direction"
    ref_level_col = f"Sweep_{tf_label}_ReferenceLevel"
    ref_ts_col = f"Sweep_{tf_label}_ReferenceTs"
    penetration_abs_col = f"Sweep_{tf_label}_PenetrationAbs"
    penetration_rel_col = f"Sweep_{tf_label}_PenetrationRel"
    penetration_band_col = f"Sweep_{tf_label}_PenetrationBand"
    penetration_model_col = f"Sweep_{tf_label}_PenetrationModelVersion"

    high_level = pd.to_numeric(out[high_price_col], errors="coerce")
    low_level = pd.to_numeric(out[low_price_col], errors="coerce")

    synthetic_mask = pd.Series(False, index=out.index)
    if "IsSynthetic" in out.columns:
        synthetic_mask = pd.to_numeric(out["IsSynthetic"], errors="coerce").fillna(0).astype(int) == 1

    raw_up = high_level.notna() & (out["High"] > high_level) & ~synthetic_mask
    raw_down = low_level.notna() & (out["Low"] < low_level) & ~synthetic_mask

    ambiguous = raw_up & raw_down
    up_candidates = raw_up & ~ambiguous
    down_candidates = raw_down & ~ambiguous

    up = _first_cross_only(up_candidates, high_level, out[high_ts_col])
    down = _first_cross_only(down_candidates, low_level, out[low_ts_col])

    out[up_col] = up.astype(bool)
    out[down_col] = down.astype(bool)

    direction = pd.Series(pd.NA, index=out.index, dtype="object")
    direction.loc[up] = "up"
    direction.loc[down] = "down"
    out[direction_col] = direction

    ref_level = pd.Series(pd.NA, index=out.index, dtype="Float64")
    ref_level.loc[up] = high_level.loc[up]
    ref_level.loc[down] = low_level.loc[down]
    out[ref_level_col] = ref_level

    ref_ts = pd.Series(pd.NaT, index=out.index, dtype="object")
    ref_ts.loc[up] = out.loc[up, high_ts_col]
    ref_ts.loc[down] = out.loc[down, low_ts_col]
    out[ref_ts_col] = pd.to_datetime(ref_ts, utc=True)

    penetration_abs = pd.Series(pd.NA, index=out.index, dtype="Float64")
    penetration_abs.loc[up] = out.loc[up, "High"] - high_level.loc[up]
    penetration_abs.loc[down] = low_level.loc[down] - out.loc[down, "Low"]
    out[penetration_abs_col] = penetration_abs

    denom = ref_level.abs().replace({0.0: pd.NA})
    out[penetration_rel_col] = (penetration_abs / denom).astype("Float64")

    penetration_band = pd.Series(pd.NA, index=out.index, dtype="object")
    rel = out[penetration_rel_col]
    penetration_band.loc[rel.notna() & (rel < 0.001)] = "shallow"
    penetration_band.loc[rel.notna() & (rel >= 0.001) & (rel < 0.003)] = "medium"
    penetration_band.loc[rel.notna() & (rel >= 0.003)] = "deep"
    out[penetration_band_col] = penetration_band

    penetration_model = pd.Series(pd.NA, index=out.index, dtype="object")
    penetration_model.loc[penetration_abs.notna()] = PENETRATION_MODEL_VERSION
    out[penetration_model_col] = penetration_model

    return out


def detect_sweeps(df: pd.DataFrame) -> pd.DataFrame:
    """Annotate strict sweeps against latest confirmed structural swings.

    Sweep definitions (strict, anti-lookahead-safe):
    - Upward sweep: ``High > latest confirmed swing high price``.
    - Downward sweep: ``Low < latest confirmed swing low price``.

    The function only references swing levels already materialized on each row via
    delayed-confirmation columns from :func:`analyzer.swings.annotate_swings`.
    """
    out = df.copy()
    for tf_label in ("H1", "H4"):
        out = _annotate_tf_sweeps(out, tf_label)
    return out
